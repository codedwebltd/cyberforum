// Inject the service
$fileService = app(FileUploadService::class);

// Upload user avatar
$result = $fileService->uploadFile($request->file('avatar'), 'social/avatars', auth()->id());

// Upload post image
$result = $fileService->uploadFile($request->file('image'), 'social/posts', auth()->id());

// Upload event file
$result = $fileService->uploadFile($request->file('document'), 'events/2024');



Route::get('test-backblaze', function () {
    return view('test-upload');
});

Route::post('test-backblaze', function (Request $request, FileUploadService $fileService) {
    try {
        if (!$request->hasFile('file')) {
            return response()->json(['error' => 'No file uploaded'], 400);
        }

        $file = $request->file('file');

        // Test upload to social/test directory
        $result = $fileService->uploadFile($file, 'social/test', 999);

        return response()->json([
            'success' => true,
            'message' => 'File uploaded successfully!',
            'data' => $result
        ]);

    } catch (Exception $e) {
        return response()->json([
            'success' => false,
            'error' => $e->getMessage()
        ], 500);
    }
});
