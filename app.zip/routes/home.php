<?php


use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Home\HomeController;
use App\Http\Controllers\OnboardingController;

/*
|--------------------------------------------------------------------------
| Home Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Add these routes to your existing routes file (web.php)
// Route::prefix('/home')->middleware(['auth'])->group(function(){
//     //landing page
//     Route::get('/',[HomeController::class, 'index'])->name('home');

//     //onboarding
//     Route::get('/onboarding',[OnboardingController::class, 'onboarding'])->name('onboarding');

//     // AJAX route to update onboarding step
//     Route::post('/onboarding/update-step', [OnboardingController::class, 'updateStep'])->name('onboarding.update-step');

//     // Route to skip onboarding
//     Route::post('/onboarding/skip', [OnboardingController::class, 'skip'])->name('onboarding.skip');

//     //console detected
//     Route::get('/console-detected', [HomeController::class, 'consoleDetected'])->name('console.detected');
// });

// Alternative: If you prefer more explicit routes without prefix
Route::middleware(['auth'])->group(function() {
    Route::get('/home', [HomeController::class, 'index'])->name('home');
    Route::get('/home/onboarding', [OnboardingController::class, 'onboarding'])->name('onboarding');
    Route::post('/home/onboarding/update-step', [OnboardingController::class, 'updateStep'])->name('onboarding.update-step');
    Route::post('/home/onboarding/skip', [OnboardingController::class, 'skip'])->name('onboarding.skip');
    Route::get('/home/console-detected', [HomeController::class, 'consoleDetected'])->name('console.detected');
});


Route::get('/dashboard', [HomeController::class, 'index'] )->middleware(['auth'])->name('dashboard');
