<?php $__env->startSection('title',"ONBOARDING"); ?>
<?php $__env->startSection('content'); ?>
    <!-- Dark Mode Toggle -->
    <button id="theme-toggle" class="fixed z-50 p-3 transition-all duration-300 bg-white border border-gray-200 rounded-full shadow-lg top-4 right-4 dark:bg-gray-800 dark:border-gray-700 hover:shadow-xl">
        <svg id="theme-toggle-dark-icon" class="hidden w-5 h-5 text-gray-700 dark:text-gray-300" fill="currentColor" viewBox="0 0 20 20">
            <path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z"></path>
        </svg>
        <svg id="theme-toggle-light-icon" class="hidden w-5 h-5 text-gray-700 dark:text-gray-300" fill="currentColor" viewBox="0 0 20 20">
            <path d="M10 2L13.09 8.26L20 9L14 14.74L15.18 21.02L10 17.77L4.82 21.02L6 14.74L0 9L6.91 8.26L10 2Z"></path>
        </svg>
    </button>

    <div class="flex flex-col min-h-screen lg:flex-row">
        <!-- Left Side - Progress & Welcome -->
        <div class="relative overflow-hidden lg:w-2/5 bg-gradient-to-br from-primary-600 via-primary-500 to-primary-700">
            <div class="absolute inset-0 bg-black/20"></div>
            <div class="relative z-10 flex flex-col items-center justify-center p-8 text-white min-h-64 lg:min-h-screen">
                <div class="max-w-md space-y-6 text-center">
                    <div class="flex items-center justify-center w-20 h-20 mx-auto bg-white/20 rounded-2xl backdrop-blur-sm animate-bounce-subtle">
                        <svg class="w-10 h-10" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
                        </svg>
                    </div>
                    <div>
                        <h1 class="mb-2 text-3xl font-bold lg:text-4xl font-poppins">Welcome to CyberForum!</h1>
                        <p class="text-lg lg:text-xl text-primary-100">Let's set up your profile</p>
                    </div>

                    <!-- Progress Indicator -->
                    <div class="w-full max-w-sm mx-auto">
                        <div class="flex items-center justify-between mb-2 text-sm">
                            <span>Step <span id="current-step">1</span> of 4</span>
                            <span id="progress-percent">25%</span>
                        </div>
                        <div class="w-full h-2 rounded-full bg-white/20">
                            <div id="progress-bar" class="h-2 transition-all duration-500 ease-out bg-white rounded-full" style="width: 25%"></div>
                        </div>
                    </div>

                    <div class="space-y-3 text-sm text-primary-200">
                        <div class="flex items-center space-x-3">
                            <svg class="w-4 h-4 text-green-300" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                            </svg>
                            <span>Profile Picture & Basic Info</span>
                        </div>
                        <div class="flex items-center space-x-3">
                            <div class="w-4 h-4 border-2 rounded-full border-primary-200"></div>
                            <span>Community Preferences</span>
                        </div>
                        <div class="flex items-center space-x-3">
                            <div class="w-4 h-4 border-2 rounded-full border-primary-200"></div>
                            <span>Interests & Skills</span>
                        </div>
                        <div class="flex items-center space-x-3">
                            <div class="w-4 h-4 border-2 rounded-full border-primary-200"></div>
                            <span>Privacy Settings</span>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Decorative Elements -->
            <div class="absolute w-32 h-32 rounded-full top-10 left-10 bg-white/10 animate-pulse-glow"></div>
            <div class="absolute w-24 h-24 rounded-full bottom-10 right-10 bg-white/5 animate-pulse-glow" style="animation-delay: 1s;"></div>
        </div>

        <!-- Right Side - Onboarding Steps -->
        <div class="flex items-center justify-center flex-1 p-6 lg:p-8">
            <div class="w-full max-w-2xl space-y-8">

                <!-- Step 1: Profile Picture & Basic Info -->
                <div id="step-1" class="step-content animate-fade-in">
                    <div class="mb-8 text-center">
                        <h2 class="mb-2 text-2xl font-bold text-gray-900 lg:text-3xl dark:text-white font-poppins">Let's start with your profile</h2>
                        <p class="text-gray-600 dark:text-gray-400">Help others recognize you in the community</p>
                    </div>

                    <form class="space-y-6">
                        <!-- Profile Picture Upload -->
                        <div class="text-center">
                            <div class="relative inline-block">
                                <div id="profile-preview" class="flex items-center justify-center w-32 h-32 overflow-hidden bg-gray-200 border-4 rounded-full dark:bg-gray-700 border-primary-200 dark:border-primary-600">
                                    <svg class="w-12 h-12 text-gray-400" fill="currentColor" viewBox="0 0 24 24">
                                        <path d="M24 20.993V24H0v-2.996A14.977 14.977 0 0112.004 15c4.904 0 9.26 2.354 11.996 5.993zM16.002 8.999a4 4 0 11-8 0 4 4 0 018 0z"/>
                                    </svg>
                                    <img id="profile-image" class="hidden object-cover w-full h-full" alt="Profile">
                                </div>
                                <button type="button" id="upload-btn" class="absolute bottom-0 right-0 p-2 text-white transition-colors rounded-full shadow-lg bg-primary-500 hover:bg-primary-600">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                                    </svg>
                                </button>
                                <input type="file" id="profile-upload" accept="image/*" class="hidden">
                            </div>
                            <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">Click the + button to upload your photo</p>
                        </div>

                        <!-- Basic Info -->
                        <div class="grid grid-cols-1 gap-6 md:grid-cols-2">
                            <div>
                                <label class="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">Date of Birth</label>
                                <input type="date" id="dob" class="w-full px-4 py-3 text-gray-900 transition-all duration-200 bg-white border border-gray-300 rounded-lg dark:border-gray-600 dark:bg-gray-800 dark:text-white focus:ring-2 focus:ring-primary-500 focus:border-transparent">
                            </div>

                            <div>
                                <label class="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">Gender</label>
                                <select id="gender" class="w-full px-4 py-3 text-gray-900 transition-all duration-200 bg-white border border-gray-300 rounded-lg dark:border-gray-600 dark:bg-gray-800 dark:text-white focus:ring-2 focus:ring-primary-500 focus:border-transparent">
                                    <option value="">Select gender</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                    <option value="non-binary">Non-binary</option>
                                    <option value="prefer-not-to-say">Prefer not to say</option>
                                </select>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 gap-6 md:grid-cols-2">
                            <div>
                                <label class="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">Location</label>
                                <input type="text" id="location" placeholder="City, Country" class="w-full px-4 py-3 text-gray-900 placeholder-gray-500 transition-all duration-200 bg-white border border-gray-300 rounded-lg dark:border-gray-600 dark:bg-gray-800 dark:text-white dark:placeholder-gray-400 focus:ring-2 focus:ring-primary-500 focus:border-transparent">
                            </div>

                            <div>
                                <label class="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">Profession</label>
                                <input type="text" id="profession" placeholder="Software Developer, Designer, etc." class="w-full px-4 py-3 text-gray-900 placeholder-gray-500 transition-all duration-200 bg-white border border-gray-300 rounded-lg dark:border-gray-600 dark:bg-gray-800 dark:text-white dark:placeholder-gray-400 focus:ring-2 focus:ring-primary-500 focus:border-transparent">
                            </div>
                        </div>



                        <div>
                            <label class="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">Bio</label>
                            <textarea id="bio" rows="3" placeholder="Tell us a bit about yourself..." class="w-full px-4 py-3 text-gray-900 placeholder-gray-500 transition-all duration-200 bg-white border border-gray-300 rounded-lg resize-none dark:border-gray-600 dark:bg-gray-800 dark:text-white dark:placeholder-gray-400 focus:ring-2 focus:ring-primary-500 focus:border-transparent"></textarea>
                            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">Maximum 150 characters</p>
                        </div>


                    </form>
                </div>

                <!-- Step 2: Community Preferences -->
                <div id="step-2" class="hidden step-content">
                    <div class="mb-8 text-center">
                        <h2 class="mb-2 text-2xl font-bold text-gray-900 lg:text-3xl dark:text-white font-poppins">Community Preferences</h2>
                        <p class="text-gray-600 dark:text-gray-400">How do you want to engage with the community?</p>
                    </div>

                    <div class="space-y-6">
                        <!-- Forum Categories -->
                        <div>
                            <label class="block mb-4 text-sm font-medium text-gray-700 dark:text-gray-300">Which topics interest you most? (Select up to 5)</label>
                            <div class="grid grid-cols-2 gap-3 md:grid-cols-3">
                                <label class="flex items-center p-3 transition-colors border border-gray-300 rounded-lg cursor-pointer dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800">
                                    <input type="checkbox" class="w-4 h-4 bg-gray-100 border-gray-300 rounded interest-checkbox text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                    <span class="ml-3 text-sm text-gray-700 dark:text-gray-300">Technology</span>
                                </label>
                                <label class="flex items-center p-3 transition-colors border border-gray-300 rounded-lg cursor-pointer dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800">
                                    <input type="checkbox" class="w-4 h-4 bg-gray-100 border-gray-300 rounded interest-checkbox text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                    <span class="ml-3 text-sm text-gray-700 dark:text-gray-300">Gaming</span>
                                </label>
                                <label class="flex items-center p-3 transition-colors border border-gray-300 rounded-lg cursor-pointer dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800">
                                    <input type="checkbox" class="w-4 h-4 bg-gray-100 border-gray-300 rounded interest-checkbox text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                    <span class="ml-3 text-sm text-gray-700 dark:text-gray-300">Design</span>
                                </label>
                                <label class="flex items-center p-3 transition-colors border border-gray-300 rounded-lg cursor-pointer dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800">
                                    <input type="checkbox" class="w-4 h-4 bg-gray-100 border-gray-300 rounded interest-checkbox text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                    <span class="ml-3 text-sm text-gray-700 dark:text-gray-300">Business</span>
                                </label>
                                <label class="flex items-center p-3 transition-colors border border-gray-300 rounded-lg cursor-pointer dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800">
                                    <input type="checkbox" class="w-4 h-4 bg-gray-100 border-gray-300 rounded interest-checkbox text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                    <span class="ml-3 text-sm text-gray-700 dark:text-gray-300">Science</span>
                                </label>
                                <label class="flex items-center p-3 transition-colors border border-gray-300 rounded-lg cursor-pointer dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800">
                                    <input type="checkbox" class="w-4 h-4 bg-gray-100 border-gray-300 rounded interest-checkbox text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                    <span class="ml-3 text-sm text-gray-700 dark:text-gray-300">Art & Creative</span>
                                </label>
                                <label class="flex items-center p-3 transition-colors border border-gray-300 rounded-lg cursor-pointer dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800">
                                    <input type="checkbox" class="w-4 h-4 bg-gray-100 border-gray-300 rounded interest-checkbox text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                    <span class="ml-3 text-sm text-gray-700 dark:text-gray-300">Sports</span>
                                </label>
                                <label class="flex items-center p-3 transition-colors border border-gray-300 rounded-lg cursor-pointer dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800">
                                    <input type="checkbox" class="w-4 h-4 bg-gray-100 border-gray-300 rounded interest-checkbox text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                    <span class="ml-3 text-sm text-gray-700 dark:text-gray-300">Health & Fitness</span>
                                </label>
                                <label class="flex items-center p-3 transition-colors border border-gray-300 rounded-lg cursor-pointer dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800">
                                    <input type="checkbox" class="w-4 h-4 bg-gray-100 border-gray-300 rounded interest-checkbox text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                    <span class="ml-3 text-sm text-gray-700 dark:text-gray-300">Entertainment</span>
                                </label>
                            </div>
                            <p id="interest-counter" class="mt-2 text-sm text-gray-500 dark:text-gray-400">0/5 selected</p>
                        </div>

                        <!-- Engagement Level -->
                        <div>
                            <label class="block mb-4 text-sm font-medium text-gray-700 dark:text-gray-300">How active do you plan to be?</label>
                            <div class="space-y-3">
                                <label class="flex items-center p-4 transition-colors border border-gray-300 rounded-lg cursor-pointer dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800">
                                    <input type="radio" name="engagement" value="lurker" class="w-4 h-4 bg-gray-100 border-gray-300 text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                    <div class="ml-3">
                                        <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Observer</div>
                                        <div class="text-xs text-gray-500 dark:text-gray-400">I prefer to read and learn from discussions</div>
                                    </div>
                                </label>
                                <label class="flex items-center p-4 transition-colors border border-gray-300 rounded-lg cursor-pointer dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800">
                                    <input type="radio" name="engagement" value="occasional" class="w-4 h-4 bg-gray-100 border-gray-300 text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                    <div class="ml-3">
                                        <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Occasional Participant</div>
                                        <div class="text-xs text-gray-500 dark:text-gray-400">I'll comment and share when I have something valuable to add</div>
                                    </div>
                                </label>
                                <label class="flex items-center p-4 transition-colors border border-gray-300 rounded-lg cursor-pointer dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800">
                                    <input type="radio" name="engagement" value="active" class="w-4 h-4 bg-gray-100 border-gray-300 text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                    <div class="ml-3">
                                        <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Active Member</div>
                                        <div class="text-xs text-gray-500 dark:text-gray-400">I plan to participate regularly in discussions and help others</div>
                                    </div>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Step 3: Interests & Skills -->
                <div id="step-3" class="hidden step-content">
                    <div class="mb-8 text-center">
                        <h2 class="mb-2 text-2xl font-bold text-gray-900 lg:text-3xl dark:text-white font-poppins">Your Skills & Interests</h2>
                        <p class="text-gray-600 dark:text-gray-400">Help others discover your expertise</p>
                    </div>

                    <div class="space-y-6">
                        <!-- Skills -->
                        <div>
                            <label class="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">Skills & Technologies</label>
                            <div class="relative">
                                <input type="text" id="skills-input" placeholder="Type a skill and press Enter (e.g., JavaScript, Photoshop, Marketing)" class="w-full px-4 py-3 text-gray-900 placeholder-gray-500 transition-all duration-200 bg-white border border-gray-300 rounded-lg dark:border-gray-600 dark:bg-gray-800 dark:text-white dark:placeholder-gray-400 focus:ring-2 focus:ring-primary-500 focus:border-transparent">
                            </div>
                            <div id="skills-container" class="flex flex-wrap gap-2 mt-3 min-h-[2rem]">
                                <!-- Skills will be added here dynamically -->
                            </div>
                        </div>

                        <!-- Experience Level -->
                        <div>
                            <label class="block mb-4 text-sm font-medium text-gray-700 dark:text-gray-300">Overall experience level</label>
                            <div class="grid grid-cols-1 gap-4 md:grid-cols-3">
                                <label class="flex flex-col items-center p-4 transition-colors border border-gray-300 rounded-lg cursor-pointer dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800">
                                    <input type="radio" name="experience" value="beginner" class="w-4 h-4 mb-2 bg-gray-100 border-gray-300 text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                    <div class="text-center">
                                        <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Beginner</div>
                                        <div class="text-xs text-gray-500 dark:text-gray-400">Just starting out</div>
                                    </div>
                                </label>
                                <label class="flex flex-col items-center p-4 transition-colors border border-gray-300 rounded-lg cursor-pointer dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800">
                                    <input type="radio" name="experience" value="intermediate" class="w-4 h-4 mb-2 bg-gray-100 border-gray-300 text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                    <div class="text-center">
                                        <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Intermediate</div>
                                        <div class="text-xs text-gray-500 dark:text-gray-400">Some experience</div>
                                    </div>
                                </label>
                                <label class="flex flex-col items-center p-4 transition-colors border border-gray-300 rounded-lg cursor-pointer dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800">
                                    <input type="radio" name="experience" value="expert" class="w-4 h-4 mb-2 bg-gray-100 border-gray-300 text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                    <div class="text-center">
                                        <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Expert</div>
                                        <div class="text-xs text-gray-500 dark:text-gray-400">Years of experience</div>
                                    </div>
                                </label>
                            </div>
                        </div>

                        <!-- Social Links -->
                        <div>
                            <label class="block mb-4 text-sm font-medium text-gray-700 dark:text-gray-300">Connect your social profiles (optional)</label>
                            <div class="space-y-3">
                                <div class="flex items-center space-x-3">
                                    <div class="flex items-center justify-center w-10 h-10 bg-blue-100 rounded-lg dark:bg-blue-900">
                                        <svg class="w-5 h-5 text-blue-600 dark:text-blue-400" fill="currentColor" viewBox="0 0 24 24">
                                            <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/>
                                        </svg>
                                    </div>
                                    <input type="url" placeholder="Twitter/X profile URL" class="flex-1 px-4 py-3 text-gray-900 placeholder-gray-500 transition-all duration-200 bg-white border border-gray-300 rounded-lg dark:border-gray-600 dark:bg-gray-800 dark:text-white dark:placeholder-gray-400 focus:ring-2 focus:ring-primary-500 focus:border-transparent">
                                </div>
                                <div class="flex items-center space-x-3">
                                    <div class="flex items-center justify-center w-10 h-10 bg-blue-100 rounded-lg dark:bg-blue-900">
                                        <svg class="w-5 h-5 text-blue-600 dark:text-blue-400" fill="currentColor" viewBox="0 0 24 24">
                                            <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                                        </svg>
                                    </div>
                                    <input type="url" placeholder="LinkedIn profile URL" class="flex-1 px-4 py-3 text-gray-900 placeholder-gray-500 transition-all duration-200 bg-white border border-gray-300 rounded-lg dark:border-gray-600 dark:bg-gray-800 dark:text-white dark:placeholder-gray-400 focus:ring-2 focus:ring-primary-500 focus:border-transparent">
                                </div>
                                <div class="flex items-center space-x-3">
                                    <div class="flex items-center justify-center w-10 h-10 bg-gray-100 rounded-lg dark:bg-gray-700">
                                        <svg class="w-5 h-5 text-gray-600 dark:text-gray-400" fill="currentColor" viewBox="0 0 24 24">
                                            <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
                                        </svg>
                                    </div>
                                    <input type="url" placeholder="GitHub profile URL" class="flex-1 px-4 py-3 text-gray-900 placeholder-gray-500 transition-all duration-200 bg-white border border-gray-300 rounded-lg dark:border-gray-600 dark:bg-gray-800 dark:text-white dark:placeholder-gray-400 focus:ring-2 focus:ring-primary-500 focus:border-transparent">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Step 4: Privacy Settings -->
                <div id="step-4" class="hidden step-content">
                    <div class="mb-8 text-center">
                        <h2 class="mb-2 text-2xl font-bold text-gray-900 lg:text-3xl dark:text-white font-poppins">Privacy & Notifications</h2>
                        <p class="text-gray-600 dark:text-gray-400">Control how you interact with the community</p>
                    </div>

                    <div class="space-y-6">
                        <!-- Profile Visibility -->
                        <div class="p-6 bg-white border border-gray-200 rounded-lg dark:bg-gray-800 dark:border-gray-700">
                            <h3 class="mb-4 text-lg font-medium text-gray-900 dark:text-white">Profile Visibility</h3>
                            <div class="space-y-4">
                                <label class="flex items-center justify-between">
                                    <div>
                                        <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Public Profile</div>
                                        <div class="text-xs text-gray-500 dark:text-gray-400">Allow others to view your profile and posts</div>
                                    </div>
                                    <input type="checkbox" checked class="w-4 h-4 bg-gray-100 border-gray-300 rounded text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                </label>
                                <label class="flex items-center justify-between">
                                    <div>
                                        <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Show Online Status</div>
                                        <div class="text-xs text-gray-500 dark:text-gray-400">Let others see when you're online</div>
                                    </div>
                                    <input type="checkbox" checked class="w-4 h-4 bg-gray-100 border-gray-300 rounded text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                </label>
                                <label class="flex items-center justify-between">
                                    <div>
                                        <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Allow Direct Messages</div>
                                        <div class="text-xs text-gray-500 dark:text-gray-400">Let other members send you private messages</div>
                                    </div>
                                    <input type="checkbox" checked class="w-4 h-4 bg-gray-100 border-gray-300 rounded text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                </label>
                            </div>
                        </div>

                        <!-- Notification Preferences -->
                        <div class="p-6 bg-white border border-gray-200 rounded-lg dark:bg-gray-800 dark:border-gray-700">
                            <h3 class="mb-4 text-lg font-medium text-gray-900 dark:text-white">Notifications</h3>
                            <div class="space-y-4">
                                <label class="flex items-center justify-between">
                                    <div>
                                        <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Email Notifications</div>
                                        <div class="text-xs text-gray-500 dark:text-gray-400">Receive important updates via email</div>
                                    </div>
                                    <input type="checkbox" checked class="w-4 h-4 bg-gray-100 border-gray-300 rounded text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                </label>
                                <label class="flex items-center justify-between">
                                    <div>
                                        <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Reply Notifications</div>
                                        <div class="text-xs text-gray-500 dark:text-gray-400">Get notified when someone replies to your posts</div>
                                    </div>
                                    <input type="checkbox" checked class="w-4 h-4 bg-gray-100 border-gray-300 rounded text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                </label>
                                <label class="flex items-center justify-between">
                                    <div>
                                        <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Weekly Digest</div>
                                        <div class="text-xs text-gray-500 dark:text-gray-400">Receive a summary of community highlights</div>
                                    </div>
                                    <input type="checkbox" class="w-4 h-4 bg-gray-100 border-gray-300 rounded text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                </label>
                                <label class="flex items-center justify-between">
                                    <div>
                                        <div class="text-sm font-medium text-gray-700 dark:text-gray-300">Marketing Communications</div>
                                        <div class="text-xs text-gray-500 dark:text-gray-400">Receive updates about new features and events</div>
                                    </div>
                                    <input type="checkbox" class="w-4 h-4 bg-gray-100 border-gray-300 rounded text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                </label>
                            </div>
                        </div>

                        <!-- Community Guidelines -->
                        <div class="p-6 border rounded-lg bg-primary-50 dark:bg-primary-900/20 border-primary-200 dark:border-primary-800">
                            <h3 class="mb-2 text-lg font-medium text-primary-900 dark:text-primary-100">Community Guidelines</h3>
                            <p class="mb-4 text-sm text-primary-700 dark:text-primary-300">
                                By completing your profile, you agree to follow our community guidelines and maintain a respectful environment for all members.
                            </p>
                            <label class="flex items-start">
                                <input type="checkbox" required class="w-4 h-4 mt-1 bg-gray-100 border-gray-300 rounded text-primary-600 dark:bg-gray-700 dark:border-gray-600 focus:ring-primary-500 focus:ring-2">
                                <span class="ml-3 text-sm text-primary-700 dark:text-primary-300">
                                    I agree to follow the community guidelines and contribute positively to discussions
                                </span>
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Navigation Buttons -->
                <div class="flex justify-between pt-6">
                    <button id="prev-btn" class="hidden px-6 py-3 text-gray-700 transition-colors border border-gray-300 rounded-lg dark:border-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800">
                        Previous
                    </button>
                    <div class="flex ml-auto space-x-4">
                        <button id="skip-btn" class="px-6 py-3 text-gray-500 transition-colors dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200">
                            Skip for now
                        </button>
                        <button id="next-btn" class="px-6 py-3 bg-primary-500 hover:bg-primary-600 text-white rounded-lg transition-all duration-200 focus:ring-4 focus:ring-primary-200 dark:focus:ring-primary-800 transform hover:scale-[1.02] active:scale-[0.98]">
                            Next
                        </button>
                        <button id="complete-btn" class="hidden px-6 py-3 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-all duration-200 focus:ring-4 focus:ring-green-200 dark:focus:ring-green-800 transform hover:scale-[1.02] active:scale-[0.98]">
                            Complete Setup
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('inc.onboarding.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dakin\Desktop\PHPSTORM GUIDE\PROJECTS\DIS\resources\views/home/onboarding.blade.php ENDPATH**/ ?>