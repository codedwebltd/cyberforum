<script>
        // Theme Toggle
        const themeToggle = document.getElementById('theme-toggle');
        const html = document.documentElement;

        themeToggle.addEventListener('click', () => {
            if (html.classList.contains('dark')) {
                html.classList.remove('dark');
                html.classList.add('light');
                localStorage.setItem('theme', 'light');
            } else {
                html.classList.remove('light');
                html.classList.add('dark');
                localStorage.setItem('theme', 'dark');
            }
        });

        // Load saved theme
        const savedTheme = localStorage.getItem('theme') || 'light';
        html.classList.remove('dark', 'light');
        html.classList.add(savedTheme);

    //rest of the codes here
    </script>




<!-- Fallback for no JavaScript -->
<noscript>
    <meta http-equiv="refresh" content="0; url=/no-javascript">
</noscript>
<script type="text/JavaScript" src="<?php echo e(asset('common/disabled.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\dakin\Desktop\PHPSTORM GUIDE\PROJECTS\DIS\resources\views/inc/home/footer.blade.php ENDPATH**/ ?>