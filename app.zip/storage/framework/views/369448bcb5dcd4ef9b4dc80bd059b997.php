
    <script>
        // Theme Toggle
        const themeToggle = document.getElementById('theme-toggle');
        const darkIcon = document.getElementById('theme-toggle-dark-icon');
        const lightIcon = document.getElementById('theme-toggle-light-icon');

        const currentTheme = localStorage.getItem('theme') || 'light';
        if (currentTheme === 'dark') {
            document.documentElement.classList.add('dark');
            darkIcon.classList.remove('hidden');
        } else {
            lightIcon.classList.remove('hidden');
        }

        themeToggle.addEventListener('click', function() {
            document.documentElement.classList.toggle('dark');

            if (document.documentElement.classList.contains('dark')) {
                localStorage.setItem('theme', 'dark');
                darkIcon.classList.remove('hidden');
                lightIcon.classList.add('hidden');
            } else {
                localStorage.setItem('theme', 'light');
                lightIcon.classList.remove('hidden');
                darkIcon.classList.add('hidden');
            }
        });

        // Onboarding Navigation
        let currentStep = 1;
        const totalSteps = 4;

        const currentStepEl = document.getElementById('current-step');
        const progressPercentEl = document.getElementById('progress-percent');
        const progressBar = document.getElementById('progress-bar');
        const prevBtn = document.getElementById('prev-btn');
        const nextBtn = document.getElementById('next-btn');
        const completeBtn = document.getElementById('complete-btn');
        const skipBtn = document.getElementById('skip-btn');

        function updateProgress() {
            const percentage = (currentStep / totalSteps) * 100;
            currentStepEl.textContent = currentStep;
            progressPercentEl.textContent = `${percentage}%`;
            progressBar.style.width = `${percentage}%`;

            // Update step visibility
            document.querySelectorAll('.step-content').forEach((step, index) => {
                if (index + 1 === currentStep) {
                    step.classList.remove('hidden');
                    step.classList.add('animate-fade-in');
                } else {
                    step.classList.add('hidden');
                    step.classList.remove('animate-fade-in');
                }
            });

            // Update button visibility
            prevBtn.classList.toggle('hidden', currentStep === 1);
            nextBtn.classList.toggle('hidden', currentStep === totalSteps);
            completeBtn.classList.toggle('hidden', currentStep !== totalSteps);
            skipBtn.classList.toggle('hidden', currentStep === totalSteps);
        }

        nextBtn.addEventListener('click', () => {
            if (currentStep < totalSteps) {
                currentStep++;
                updateProgress();
            }
        });

        prevBtn.addEventListener('click', () => {
            if (currentStep > 1) {
                currentStep--;
                updateProgress();
            }
        });

        completeBtn.addEventListener('click', () => {
            alert('Profile setup complete! Welcome to CyberForum!');
            window.location.href = 'forum-template.html';
        });

        skipBtn.addEventListener('click', () => {
            if (confirm('Are you sure you want to skip this step?')) {
                window.location.href = 'forum-template.html';
            }
        });

        // Profile Picture Upload
        const uploadBtn = document.getElementById('upload-btn');
        const profileUpload = document.getElementById('profile-upload');
        const profilePreview = document.getElementById('profile-preview');
        const profileImage = document.getElementById('profile-image');

        uploadBtn.addEventListener('click', () => {
            profileUpload.click();
        });

        profileUpload.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    profileImage.src = e.target.result;
                    profileImage.classList.remove('hidden');
                    profilePreview.querySelector('svg').classList.add('hidden');
                };
                reader.readAsDataURL(file);
            }
        });

        // Interest Selection (Max 5)
        const interestCheckboxes = document.querySelectorAll('.interest-checkbox');
        const interestCounter = document.getElementById('interest-counter');

        function updateInterestCounter() {
            const selected = document.querySelectorAll('.interest-checkbox:checked').length;
            interestCounter.textContent = `${selected}/5 selected`;

            // Disable unchecked boxes if 5 are selected
            interestCheckboxes.forEach(checkbox => {
                if (!checkbox.checked) {
                    checkbox.disabled = selected >= 5;
                    checkbox.parentElement.classList.toggle('opacity-50', selected >= 5);
                }
            });
        }

        interestCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', updateInterestCounter);
        });

        // Skills Input
        const skillsInput = document.getElementById('skills-input');
        const skillsContainer = document.getElementById('skills-container');
        const skills = [];

        skillsInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && skillsInput.value.trim()) {
                e.preventDefault();
                const skill = skillsInput.value.trim();
                if (!skills.includes(skill)) {
                    skills.push(skill);
                    addSkillTag(skill);
                    skillsInput.value = '';
                }
            }
        });

        function addSkillTag(skill) {
            const tag = document.createElement('span');
            tag.className = 'inline-flex items-center px-3 py-1 rounded-full text-sm bg-primary-100 dark:bg-primary-900 text-primary-800 dark:text-primary-200 border border-primary-200 dark:border-primary-700';
            tag.innerHTML = `
                ${skill}
                <button type="button" class="ml-2 hover:text-primary-600 dark:hover:text-primary-400" onclick="removeSkill(this, '${skill}')">
                    <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                    </svg>
                </button>
            `;
            skillsContainer.appendChild(tag);
        }

        function removeSkill(button, skill) {
            const index = skills.indexOf(skill);
            if (index > -1) {
                skills.splice(index, 1);
                button.parentElement.remove();
            }
        }

        // Bio character counter
        const bioTextarea = document.getElementById('bio');
        if (bioTextarea) {
            bioTextarea.addEventListener('input', function() {
                const maxLength = 150;
                const currentLength = this.value.length;
                const counter = this.nextElementSibling;

                if (currentLength > maxLength) {
                    this.value = this.value.substring(0, maxLength);
                }

                counter.textContent = `${Math.min(currentLength, maxLength)}/${maxLength} characters`;
                counter.classList.toggle('text-red-500', currentLength >= maxLength);
            });
        }

        // Initialize
        updateProgress();
        updateInterestCounter();
    </script>
    <script type="text/JavaScript" src="<?php echo e(asset('common/disabled.js')); ?>"></script>
<?php /**PATH /var/www/html/resources/views/inc/onboarding/footer.blade.php ENDPATH**/ ?>