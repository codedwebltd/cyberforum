<script type="text/JavaScript" src="<?php echo e(asset('common/disabled.js')); ?>"></script>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/inc/auth/footer.blade.php ENDPATH**/ ?>