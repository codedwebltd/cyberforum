<?php echo $__env->make('inc.home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>;
<?php echo $__env->make('inc.home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\dakin\Desktop\PHPSTORM GUIDE\PROJECTS\DIS\resources\views/inc/home/app.blade.php ENDPATH**/ ?>