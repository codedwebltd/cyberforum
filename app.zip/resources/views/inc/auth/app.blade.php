@include('inc.auth.header')
@yield('content')
@include('inc.auth.footer')
