<script type="text/JavaScript" src="{{ asset('common/disabled.js') }}"></script>
</body>
</html>
