@include('inc.onboarding.header')
@yield('content')
@include('inc.onboarding.footer')
