@include('inc.home.header')
@yield('content');
@include('inc.home.footer')
