<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $messageData['subject'] ?? 'Notification' }}</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 0; background-color: #f8fafc; }
        .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; }
        .logo { font-size: 24px; font-weight: bold; margin-bottom: 8px; }
        .content { padding: 30px; }
        .message { color: #4a5568; line-height: 1.6; margin-bottom: 25px; }
        .alert { padding: 15px; border-radius: 6px; margin: 20px 0; }
        .alert-success { background: #f0fff4; border: 1px solid #c6f6d5; color: #22543d; }
        .alert-error { background: #fed7d7; border: 1px solid #feb2b2; color: #742a2a; }
        .alert-info { background: #ebf8ff; border: 1px solid #bee3f8; color: #2a4365; }
        .button { display: inline-block; background: #667eea; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: 600; margin: 10px 0; }
        .footer { background: #2d3748; color: #a0aec0; padding: 25px; text-align: center; font-size: 14px; }
        .timestamp { font-size: 12px; color: #718096; margin-top: 15px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="logo">{{ $appName }}</div>
            <p>{{ $messageData['subject'] ?? 'Notification' }}</p>
        </div>

        <div class="content">
            <h2>Hello {{ $messageData['user_name'] ?? 'There' }}!</h2>

            @php
                $alertClass = match($messageData['type'] ?? 'info') {
                    'success' => 'alert-success',
                    'error' => 'alert-error',
                    default => 'alert-info'
                };
            @endphp

            <div class="alert {{ $alertClass }}">
                <div class="message">
                    {!! nl2br(e($messageData['response'])) !!}
                </div>
            </div>

            @if(isset($messageData['action_url']))
                <div style="text-align: center; margin: 25px 0;">
                    <a href="{{ $messageData['action_url'] }}" class="button">
                        {{ $messageData['action_text'] ?? 'View Details' }}
                    </a>
                </div>
            @endif

            <div class="timestamp">
                Sent on {{ now()->format('F j, Y \a\t g:i A') }}
            </div>
        </div>

        <div class="footer">
            <p>&copy; {{ date('Y') }} {{ $appName }}. All rights reserved.</p>
            <p>You're receiving this because of your notification preferences.</p>
            <p><a href="{{ config('app.url') }}/settings" style="color: #a0aec0;">Update your notification preferences</a></p>
        </div>
    </div>
</body>
</html>
