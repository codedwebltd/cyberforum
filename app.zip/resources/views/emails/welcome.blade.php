<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Welcome to {{ $appName }}</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 0; background-color: #f8fafc; }
        .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 40px 30px; text-align: center; }
        .logo { font-size: 28px; font-weight: bold; margin-bottom: 10px; }
        .content { padding: 40px 30px; }
        .welcome-text { font-size: 24px; color: #2d3748; margin-bottom: 20px; }
        .message { color: #4a5568; line-height: 1.6; margin-bottom: 30px; }
        .button { display: inline-block; background: #667eea; color: white; padding: 15px 30px; text-decoration: none; border-radius: 6px; font-weight: 600; }
        .stats { background: #f7fafc; padding: 25px; border-radius: 8px; margin: 30px 0; }
        .stat-item { display: inline-block; margin: 0 20px; text-align: center; }
        .stat-number { font-size: 24px; font-weight: bold; color: #667eea; }
        .stat-label { font-size: 14px; color: #718096; }
        .footer { background: #2d3748; color: #a0aec0; padding: 30px; text-align: center; font-size: 14px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="logo">{{ $appName }}</div>
            <p>Welcome to the Community</p>
        </div>

        <div class="content">
            <h1 class="welcome-text">Welcome, {{ $user->name }}!</h1>

            <div class="message">
                <p>We're excited to have you join our vibrant community of professionals, creators, and innovators. Your journey starts here!</p>

                <p>Here's what you can do next:</p>
                <ul>
                    <li>Complete your profile setup</li>
                    <li>Upload your first post</li>
                    <li>Connect with other members</li>
                    <li>Explore the marketplace</li>
                </ul>
            </div>

            <div class="stats">
                <div class="stat-item">
                    <div class="stat-number">100</div>
                    <div class="stat-label">Welcome Points</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">{{ $user->referral_code }}</div>
                    <div class="stat-label">Your Referral Code</div>
                </div>
            </div>

            <div style="text-align: center;">
                <a href="{{ $appUrl }}/dashboard" class="button">Get Started</a>
            </div>

            <div class="message" style="margin-top: 40px; border-top: 1px solid #e2e8f0; padding-top: 30px;">
                <p><strong>Need help?</strong> Our community is here to support you. If you have any questions, don't hesitate to reach out.</p>
                <p>Username: <strong>{{ $user->username }}</strong><br>
                Email: {{ $user->email }}</p>
            </div>
        </div>

        <div class="footer">
            <p>&copy; {{ date('Y') }} {{ $appName }}. All rights reserved.</p>
            <p>You're receiving this email because you created an account with us.</p>
        </div>
    </div>
</body>
</html>
