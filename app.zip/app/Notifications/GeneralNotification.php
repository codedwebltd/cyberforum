<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class GeneralNotification extends Notification implements ShouldQueue
{
    use Queueable;

    private $notificationData;

    public function __construct($data)
    {
        $this->notificationData = $data;
    }

    public function via($notifiable)
    {
        $channels = ['database']; // Always store in database

        // Check user settings for email notifications
        $userSettings = $notifiable->settings;

        if ($userSettings && $userSettings->email_notifications) {
            $channels[] = 'mail';
        }

        // Add push notifications if enabled
        if ($userSettings && $userSettings->push_notifications) {
            // $channels[] = 'fcm'; // Add when implementing push notifications
        }

        return $channels;
    }

    public function toMail($notifiable)
    {
        return (new MailMessage)
                    ->subject($this->notificationData['subject'] ?? 'Notification from ' . config('app.name'))
                    ->greeting('Hello ' . $notifiable->name)
                    ->line($this->notificationData['message'])
                    ->action('View Dashboard', url('/dashboard'));
    }

    public function toArray($notifiable)
    {
        return [
            'message' => $this->notificationData['message'],
            'type' => $this->notificationData['type'] ?? 'info',
            'created_at' => now(),
        ];
    }
}
