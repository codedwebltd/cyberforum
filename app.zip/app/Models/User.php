<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;

    protected $fillable = [
        'name',
        'email',
        'password',
        'password_confirmation',
        'username',
        'bio',
        'avatar_url',
        'cover_url',
        'location',
        'website',
        'date_of_birth',
        'gender',
        'points',
        'reputation',
        'is_verified',
        'is_admin',
        'is_active',
        'profile_public',
        'show_email',
        'allow_messages',
        'location_history',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'date_of_birth' => 'date',
        'last_active_at' => 'datetime',
        'is_verified' => 'boolean',
        'is_admin' => 'boolean',
        'is_active' => 'boolean',
        'onboarding_completed' => 'boolean',
        'profile_public' => 'boolean',
        'show_email' => 'boolean',
        'allow_messages' => 'boolean',
        'password' => 'hashed',
         'location_history' => 'array',
    ];

    // Relationships
    public function wallet(): HasOne
    {
        return $this->hasOne(Wallet::class);
    }

    public function settings(): HasOne
    {
        return $this->hasOne(UserSetting::class);
    }

    public function onboardingSteps(): HasMany
    {
        return $this->hasMany(OnboardingStep::class);
    }

    public function posts(): HasMany
    {
        return $this->hasMany(Post::class);
    }

    public function comments(): HasMany
    {
        return $this->hasMany(Comment::class);
    }

    public function likes(): HasMany
    {
        return $this->hasMany(Like::class);
    }

    // Scopes
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeVerified($query)
    {
        return $query->where('is_verified', true);
    }

    public function scopeOnlineRecently($query, $minutes = 15)
    {
        return $query->where('last_active_at', '>=', now()->subMinutes($minutes));
    }

    public function scopeByReputation($query, $order = 'desc')
    {
        return $query->orderBy('reputation', $order);
    }

    public function scopeByPoints($query, $order = 'desc')
    {
        return $query->orderBy('points', $order);
    }

    public function scopeCompletedProfile($query)
    {
        return $query->where('profile_completion_percentage', '>=', 80);
    }

    // Accessors
    public function getFullNameAttribute(): string
    {
        return $this->name;
    }

    public function getDisplayNameAttribute(): string
    {
        return $this->username ?: $this->name;
    }

    public function getIsOnlineAttribute(): bool
    {
        return $this->last_active_at && $this->last_active_at->diffInMinutes(now()) <= 15;
    }

    // Methods
    public function updateLastActive(): void
    {
        $this->update(['last_active_at' => now()]);
    }

    public function incrementPoints(int $points): void
    {
        $this->increment('points', $points);
    }

    public function calculateProfileCompletion(): int
    {
        $fields = [
            'avatar_url', 'bio', 'location', 'website',
            'date_of_birth', 'gender'
        ];

        $completed = collect($fields)->filter(fn($field) => !is_null($this->$field))->count();
        $percentage = round(($completed / count($fields)) * 100);

        $this->update(['profile_completion_percentage' => $percentage]);

        return $percentage;
    }

    public function hasCompletedOnboarding(): bool
    {
        return $this->onboarding_completed;
    }
}
