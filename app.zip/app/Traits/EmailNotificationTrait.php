<?php

namespace App\Traits;

use App\Models\User;
use App\Mail\WelcomeUserMail;
use App\Mail\GeneralNotificationMail;
use App\Notifications\GeneralNotification;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;

trait EmailNotificationTrait
{
    public function ActionNotification($userId, $message): void
    {
        try {
            $user = User::with('settings')->find($userId);
            if (!$user) {
                Log::error('User not found for notification', ['user_id' => $userId]);
                return;
            }

            // Prepare notification data
            $notificationData = [
                'message' => $message['response'],
                'subject' => $message['subject'] ?? 'Notification from ' . config('app.name'),
                'type' => $message['type'] ?? 'info'
            ];

            // Send notification (will check user settings internally)
            $user->notify(new GeneralNotification($notificationData));

            // Notify admin if required
            if ($message['notify_admin'] ?? false) {
                $adminEmail = config('app.admin_email', 'admin@example.com');
                Mail::to($adminEmail)->send(new GeneralNotificationMail($message));
            }

        } catch (\Exception $e) {
            Log::error('Notification failed', [
                'user_id' => $userId,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
        }
    }

    public function sendWelcomeEmail(User $user): void
    {
        try {
            Mail::to($user->email)->send(new WelcomeUserMail($user));
        } catch (\Exception $e) {
            Log::error('Welcome email failed', [
                'user_id' => $user->id,
                'email' => $user->email,
                'error' => $e->getMessage()
            ]);
        }
    }

    public function sendEmailVerification(User $user): void
    {
        try {
            $user->sendEmailVerificationNotification();
        } catch (\Exception $e) {
            Log::error('Email verification failed', [
                'user_id' => $user->id,
                'error' => $e->getMessage()
            ]);
        }
    }
}
