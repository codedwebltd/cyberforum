<?php

namespace App\Http\Controllers\Onboarding;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Cloak extends Controller
{
    //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
}
