<?php

namespace App\Http\Controllers\Home;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\RateLimiter;

class HomeController extends Controller
{
    public function index()
    {
        // Check if user is authenticated and onboarding is incomplete
        if (auth()->check() && !auth()->user()->onboarding_completed) {
            return redirect()->route('onboarding');
        }

        return view('home.index');
    }

    public function onboarding()
    {
        // Redirect if user is not authenticated
        if (!auth()->check()) {
            return redirect()->route('login');
        }

        // Redirect if onboarding is already completed
        if (auth()->user()->onboarding_completed) {
            return redirect()->route('/home');
        }

        return view('home.onboarding');
    }
    public function consoleDetected(Request $request)
{
    // Log the console detection attempt
    Log::warning('Developer console access detected', [
        'ip' => $request->ip(),
        'user_agent' => $request->userAgent(),
        'timestamp' => now(),
        'user_id' => auth()->id(),
        'referrer' => $request->header('referer')
    ]);

    // Extract location data for security logging
    if (method_exists($this, 'extractLocationData')) {
        $locationData = $this->extractLocationData();
        Log::info('Console detection location', $locationData);
    }

    // If user is authenticated, log to their security history
    if (auth()->check()) {
        $user = auth()->user();
        $this->logSecurityEvent($user, 'console_access_attempt');
    }

    // Rate limit console detection to prevent spam
    $key = 'console_detected:' . $request->ip();
    if (RateLimiter::tooManyAttempts($key, 5)) {
        abort(429, 'Too many attempts');
    }
    RateLimiter::hit($key, 300); // 5 minutes

    return response()->view('security.console-detected', [
        'timestamp' => now()->format('Y-m-d H:i:s'),
        'ip' => $request->ip()
    ])->header('X-Frame-Options', 'DENY');
}

private function logSecurityEvent($user, $eventType)
{
    $locationHistory = $user->location_history ?? [];

    $securityEvent = [
        'event_type' => $eventType,
        'timestamp' => now()->toISOString(),
        'ip' => request()->ip(),
        'user_agent' => request()->userAgent(),
        'session_id' => session()->getId()
    ];

    $locationHistory[] = $securityEvent;

    // Keep only last 100 security events
    if (count($locationHistory) > 100) {
        $locationHistory = array_slice($locationHistory, -100);
    }

    $user->update(['location_history' => $locationHistory]);
}
}
