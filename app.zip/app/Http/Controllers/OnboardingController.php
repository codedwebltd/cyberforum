<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\UserSettings;
use App\Models\OnboardingStep;
use App\Services\FileUploadService;
use App\Traits\LocationTrait;

class OnboardingController extends Controller
{
    use LocationTrait;

    public function onboarding()
    {
        $user = auth()->user();
        $completedSteps = $user->onboardingSteps()->where('is_completed', true)->pluck('step_name');

        return view('home.onboarding', compact('completedSteps'));
    }

    public function updateStep(Request $request)
    {
        $user = auth()->user();
        $stepName = $request->step_name;

        $stepData = match($stepName) {
            'profile_basic_info' => $this->handleProfileBasicInfo($request, $user),
            'community_preferences' => $this->handleCommunityPreferences($request, $user),
            'interests_skills' => $this->handleInterestsSkills($request, $user),
            'privacy_settings' => $this->handlePrivacySettings($request, $user),
            default => []
        };

        // Mark step as completed
        OnboardingStep::updateOrCreate(
            ['user_id' => $user->id, 'step_name' => $stepName],
            [
                'is_completed' => true,
                'completed_at' => now(),
                'step_data' => $stepData,
                'attempts' => 1,
                'last_attempt_at' => now()
            ]
        );

        // Update profile completion percentage
        $user->calculateProfileCompletion();

        // Check if all steps completed
        $totalSteps = OnboardingStep::where('user_id', $user->id)->count();
        $completedSteps = OnboardingStep::where('user_id', $user->id)
            ->where('is_completed', true)->count();

        if ($totalSteps === $completedSteps) {
            $user->update(['onboarding_completed' => true]);
            $this->logUserLocation('onboarding_completed');
        }

        return response()->json(['success' => true, 'message' => 'Step completed successfully']);
    }

    private function handleProfileBasicInfo(Request $request, User $user): array
    {
        $request->validate([
            'date_of_birth' => 'nullable|date|before:today',
            'gender' => 'nullable|in:male,female,non-binary,prefer-not-to-say',
            'location' => 'nullable|string|max:255',
            'profession' => 'nullable|string|max:255',
            'bio' => 'nullable|string|max:150',
            'avatar' => 'nullable|image|max:2048'
        ]);

        $updateData = [
            'date_of_birth' => $request->date_of_birth,
            'gender' => $request->gender,
            'location' => $request->location,
            'bio' => $request->bio,
        ];

        // Handle avatar upload
        if ($request->hasFile('avatar')) {
            $fileService = app(FileUploadService::class);
            $result = $fileService->uploadFile(
                $request->file('avatar'),
                'social/avatars',
                $user->id
            );
            $updateData['avatar_url'] = $result['url'];
        }

        $user->update(array_filter($updateData));

        return [
            'profession' => $request->profession,
            'completed_fields' => count(array_filter($updateData))
        ];
    }

    private function handleCommunityPreferences(Request $request, User $user): array
    {
        $request->validate([
            'interests' => 'array|max:5',
            'interests.*' => 'string|in:technology,gaming,design,business,science,art-creative,sports,health-fitness,entertainment',
            'engagement_level' => 'required|in:lurker,occasional,active'
        ]);

        $settings = $user->settings;
        $settings->update([
            'content_preferences' => json_encode([
                'interests' => $request->interests ?? [],
                'engagement_level' => $request->engagement_level
            ])
        ]);

        return [
            'interests' => $request->interests ?? [],
            'engagement_level' => $request->engagement_level,
            'interest_count' => count($request->interests ?? [])
        ];
    }

    private function handleInterestsSkills(Request $request, User $user): array
    {
        $request->validate([
            'skills' => 'array',
            'skills.*' => 'string|max:50',
            'experience_level' => 'required|in:beginner,intermediate,expert',
            'social_links' => 'array',
            'social_links.twitter' => 'nullable|url',
            'social_links.linkedin' => 'nullable|url',
            'social_links.github' => 'nullable|url'
        ]);

        return [
            'skills' => $request->skills ?? [],
            'experience_level' => $request->experience_level,
            'social_links' => array_filter($request->social_links ?? []),
            'skills_count' => count($request->skills ?? [])
        ];
    }

    private function handlePrivacySettings(Request $request, User $user): array
    {
        $request->validate([
            'profile_public' => 'boolean',
            'show_online_status' => 'boolean',
            'allow_messages' => 'boolean',
            'email_notifications' => 'boolean',
            'reply_notifications' => 'boolean',
            'weekly_digest' => 'boolean',
            'marketing_emails' => 'boolean'
        ]);

        // Update user privacy settings
        $user->update([
            'profile_public' => $request->boolean('profile_public', true),
            'show_online_status' => $request->boolean('show_online_status', true),
            'allow_messages' => $request->boolean('allow_messages', true)
        ]);

        // Update user settings
        $user->settings->update([
            'email_notifications' => $request->boolean('email_notifications', true),
            'reply_notifications' => $request->boolean('reply_notifications', true),
            'weekly_digest' => $request->boolean('weekly_digest', false),
            'marketing_emails' => $request->boolean('marketing_emails', false)
        ]);

        return [
            'privacy_level' => $request->boolean('profile_public') ? 'public' : 'private',
            'notification_count' => collect([
                $request->boolean('email_notifications'),
                $request->boolean('reply_notifications'),
                $request->boolean('weekly_digest'),
                $request->boolean('marketing_emails')
            ])->filter()->count()
        ];
    }

    public function skip(Request $request)
    {
        $user = auth()->user();
        $user->update(['onboarding_completed' => true]);

        $this->logUserLocation('onboarding_skipped');

        return response()->json(['success' => true, 'redirect' => route('dashboard')]);
    }
}
